resource "google_compute_instance" "vm" {

  name         = "terraform-vm"

  machine_type = "e2-micro"

  zone = var.zone

  boot_disk {

    initialize_params {

      image = "debian-cloud/debian-12"

      size = 20
    }
  }

  network_interface {

    network = "default"

    access_config {

    }

  }

}