project_id = "project-56b2f5d2-7168-44bb-ab5"
region = "asia-southeast2"
zone = "asia-southeast2-a"